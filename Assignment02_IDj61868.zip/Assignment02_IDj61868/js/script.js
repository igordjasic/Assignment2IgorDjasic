document.addEventListener("DOMContentLoaded", async function () {
  var contactTotal = 22;                                          //Request a total amount of contacts here. If you change this number, the pagination will adapt to the chosen number.

  var api = 'https://randomuser.me/api/?results=' + contactTotal;

  var response = await fetch(api);
  var data = await response.json();

  var database = data.results;
  const contact = JSON.stringify(database); //Stringifying api to JSON string 

  localStorage.setItem("contact", contactTotal); //Sending api amount to script

  var totalOutput = document.getElementById("totalNum");
  totalOutput.innerText = "Total: " + JSON.parse(contact).length; //Changes "Total:" counter

  var studentsData = [];

  const studentsPerPage = 10;
  const totalPages = Math.ceil(contactTotal / studentsPerPage);

  for (let i = 0; i < contactTotal; i++) {
    studentsData.push({
      name: { first: database[i].name.first, last: database[i].name.last },
      picture: database[i].picture.thumbnail,
      email: database[i].email,
      joinedDate: `Joined ${database[i].registered.date}`,
    });
  }

  function displayStudents() {
    const studentListContainer = document.querySelector(".contact-list");   
    studentListContainer.innerHTML = "";
  
    //calc range of students for current page
    const startIndex = (currentPage - 1) * studentsPerPage;
    const endIndex = startIndex + studentsPerPage;
    
    //extract students for the current page
    const currentStudents = studentsData.slice(startIndex, endIndex);
  
    currentStudents.forEach((student) => {                 //Foreach statement that creates each contact
      const studentItem = document.createElement("li");
      studentItem.classList.add("contact-item", "cf");
  
      const contactDetails = document.createElement("div");
      contactDetails.classList.add("contact-details");
  
      const avatar = document.createElement("img");
      avatar.classList.add("avatar");
      avatar.src = student.picture;
  
      const name = document.createElement("h3");
      name.textContent = `${student.name.first} ${student.name.last}`;
  
      const email = document.createElement("span");
      email.classList.add("email");
      email.textContent = student.email;
  
      contactDetails.appendChild(avatar);
      contactDetails.appendChild(name);
      contactDetails.appendChild(email);
  
      const joinedDetails = document.createElement("div");  //extracting date and creating seperate div for it  
      joinedDetails.classList.add("joined-details");
  
      const joinedDate = document.createElement("span");
      joinedDate.classList.add("date");
      
                                          
      const dateWithoutTime = student.joinedDate.split('T')[0];
      joinedDate.textContent = ` ${dateWithoutTime}`;
  
      joinedDetails.appendChild(joinedDate);
  
      studentItem.appendChild(contactDetails);
      studentItem.appendChild(joinedDetails);
  
      studentListContainer.appendChild(studentItem);
    });
  }

  function displayPagination() {                               //function to create pagination 
    const pageContainer = document.getElementById("pagination-container");
    pageContainer.innerHTML = '';

    const paginationList = document.createElement("ul");
    paginationList.classList.add("pagination-list");

    for (let i = 1; i <= totalPages; i++) {
      const listItem = document.createElement("li");

      const pageLink = document.createElement("a");
      pageLink.textContent = i;
      pageLink.href = "#";
      pageLink.addEventListener("click", (event) => {
        event.preventDefault();
        currentPage = i;
        displayStudents();
      });

      listItem.appendChild(pageLink);
      paginationList.appendChild(listItem);
    }
    pageContainer.appendChild(paginationList);
  }

  let currentPage = 1;

  displayStudents();
  displayPagination();
});
